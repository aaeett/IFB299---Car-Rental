# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase
from .models import Car


# Create your tests here.
class CarTest(TestCase):
    def setup(self):
        Car.objects.All()

    def test_data_id(self):
        cars = Car.objects.get(car_series = 'HSE')
        self.assertEqual(car1.car_seriesyear, 2006)
