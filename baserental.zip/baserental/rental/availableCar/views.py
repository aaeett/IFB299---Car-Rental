# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from django.views.generic import TemplateView
from django.shortcuts import render

from .models import Car, Car1
from .forms import SearchCarForm

# Create your views here.

def get_car(request):
    data = Car.objects.all()
    if request.method == 'POST':
        c_id = request.POST['car_id_']

    theCar = Car.objects.get(car_id = c_id)

    recommendation_list = []
    n=1
    for car in data:
        if car.car_make_model == theCar.car_make_model and n <= 5:
            recommendation_list.append(car)
            n = n + 1;


    stu = {
        'theCar': theCar,
        'recommendation_list': recommendation_list,
    }

    return render(request, 'availableCar/theCar.html', stu)

def availableCar(request):
    form = SearchCarForm()
    data = Car.objects.all()
    stu = {
        "car_id": data,
        'form': form,
    }

    return render(request, 'availableCar/avaiCar.html', stu)

def post(request):
    form = SearchCarForm(request.POST)
    data = Car.objects.all()

    if form.is_valid():
        price_from = form.cleaned_data['price_from']
        price_to = form.cleaned_data['price_to']
        car_model = form.cleaned_data['car_model']

    list1 = []

    for car in data:
        if car.car_make_model == car_model and car.car_pricenew <= price_to and car.car_pricenew >= price_from:
            list1.append(car)

    t = len(list1)



    args = {
        'form': form,
        'car_id': data,
        'price_from': price_from,
        'price_to': price_to,
        'car_model': car_model,
        'Car1' : Car1,
        'list1' : list1,
        't' : t,
    }



    return render(request, 'availableCar/results.html', args)
