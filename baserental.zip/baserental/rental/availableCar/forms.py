

from django import forms
from .models import Car



class SearchCarForm(forms.Form):
    price_from = forms.DecimalField();
    price_to = forms.DecimalField();
    car_model = forms.CharField();
