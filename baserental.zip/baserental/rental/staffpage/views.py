# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

from .models import Orders, Customers, Store, Car

# Create your views here.

def staffpage(request):
    data = Orders.objects.all()
    stu = {
        "order_id": data
    }
    return render(request, 'staffpage/staffpage.html', stu)


def customerpage(request):
    data = Customers.objects.all()
    stu = {
        "customer_id": data
    }
    return render(request, 'staffpage/customer.html', stu)


def storepage(request):
    data = Store.objects.all()
    stu = {
        "store_id": data
    }
    return render(request, 'staffpage/store.html', stu)


def reportpage(request):
    order = Orders.objects.all()
    store = Store.objects.all()
    customer = Customers.objects.all()

    list1 = []



    for order_ in order:
        if order_.order_pickupstore == '3':
            list1.append(order_)
    count = len(list1) # number of car pick up in this store.



    stu = {
        "order_id": order,
        "store_id": store,
        "customer_id": customer,
        "list1": list1
    }






    return render(request, 'staffpage/report.html', stu)
